#!/bin/bash

export FLASK_APP=mflix/mflix.py
export FLASK_DEBUG=false
export MFLIX_DB_URI="XXXX" # Replace XXXX with your MongoDB Connection URI